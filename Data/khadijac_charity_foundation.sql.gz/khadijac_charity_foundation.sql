-- MySQL dump 10.13  Distrib 5.7.42, for Linux (x86_64)
--
-- Host: localhost    Database: khadijac_charity_foundation
-- ------------------------------------------------------
-- Server version	5.7.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comments` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` text,
  `user_comment` int(11) DEFAULT NULL,
  `post_comment` int(11) DEFAULT NULL,
  PRIMARY KEY (`comment_id`),
  KEY `user_comment` (`user_comment`),
  KEY `post_comment` (`post_comment`),
  CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`user_comment`) REFERENCES `users` (`user_id`),
  CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`post_comment`) REFERENCES `posts` (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
INSERT INTO `comments` (`comment_id`, `comment`, `user_comment`, `post_comment`) VALUES (8,'Good',1,33),(9,'Allah save you and your team ❤️',11,38);
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts` (
  `post_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_Image` text,
  `post_title` varchar(255) DEFAULT NULL,
  `post_description` text,
  `post_phone` varchar(20) DEFAULT NULL,
  `post_address` varchar(255) DEFAULT NULL,
  `post_user` int(11) DEFAULT NULL,
  PRIMARY KEY (`post_id`),
  KEY `post_user` (`post_user`),
  CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`post_user`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` (`post_id`, `post_Image`, `post_title`, `post_description`, `post_phone`, `post_address`, `post_user`) VALUES (33,'https://res.cloudinary.com/dskt3xxtq/image/upload/v1682694664/uploads/psz9fgwqyizmr8k4byuq.jpg','Helping People','Helping People is another kindness','0000','None',1),(34,'https://res.cloudinary.com/dskt3xxtq/image/upload/v1683043408/uploads/sdqti56rammftl9ktifz.jpg','Giving Bread','We are here to help people allah gives us alot of things for taking exam and we should spend our time with poor people it make happy ourself ','0000','Afghanistan , Kabul',1),(35,'https://res.cloudinary.com/dskt3xxtq/image/upload/v1683043798/uploads/nf1qbtxfbmksaj7llh5j.jpg','Help Place','That is not importent which where are you from and where are you live the importent is how you help people if you help one person you helped all humanity ...','0000','Afghanistan, Kabul',1),(37,'https://res.cloudinary.com/dskt3xxtq/image/upload/v1683044340/uploads/tpaok1zdmggokawhwewz.jpg','Help On Street','The Prophet Muhammad (peace be upon him) said: “Whoever feeds someone who is hungry will have his sins forgiven, and whoever helps someone to travel will have his sins forgiven.','0000','Afghanistan , Kabul',1),(38,'https://res.cloudinary.com/dskt3xxtq/image/upload/v1683044794/uploads/p94fzkw4gpjzuhkfwpfn.jpg','Help People In Market','“Those who in charity spend of their goods by night and by day, in secret and in public, have their reward with their Lord: on them shall be no fear, nor shall they grieve”. “Allah will deprive usury of all blessing, but will give increase for deeds of charity.','0000','Afghanistan ,Kabul',1);
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slideshow`
--

DROP TABLE IF EXISTS `slideshow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slideshow` (
  `slide_id` int(11) NOT NULL AUTO_INCREMENT,
  `slide_title` varchar(200) DEFAULT NULL,
  `slide_descrption` text,
  `slide_image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`slide_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slideshow`
--

LOCK TABLES `slideshow` WRITE;
/*!40000 ALTER TABLE `slideshow` DISABLE KEYS */;
INSERT INTO `slideshow` (`slide_id`, `slide_title`, `slide_descrption`, `slide_image`) VALUES (18,'Help','Helping kids','https://res.cloudinary.com/dskt3xxtq/image/upload/v1682398315/uploads/ysethmtmkmucjxqxnhcm.jpg'),(20,'New Place','Our new place for helping people and help poor people','https://res.cloudinary.com/dskt3xxtq/image/upload/v1683042874/uploads/umeteicfdtjufljt3bsg.jpg');
/*!40000 ALTER TABLE `slideshow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(200) DEFAULT NULL,
  `user_email` varchar(200) DEFAULT NULL,
  `user_password` text,
  `user_type` varchar(100) DEFAULT NULL,
  `user_image` text NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`user_id`, `user_name`, `user_email`, `user_password`, `user_type`, `user_image`) VALUES (1,'Hamza','Hamza.Nawabi119@gmail.com','$2a$10$P2l74K91YW23/Rt/qsInnugm6nV39sjZtPi0oM9aGAMm3vd9PFJbG','Super Admin','https://res.cloudinary.com/dskt3xxtq/image/upload/v1681731229/uploads/hhe5ts6guqgb2kei7mow.png'),(5,'wahid','wahid@gmail.com','$2a$10$q.4387fBE1ppHCUFmJYF9.eOT9yMlOEqNjD5w.6StCSuzrVxdb3TC','User','https://res.cloudinary.com/dskt3xxtq/image/upload/v1680914976/uploads/hxxdwk5sc1fiadxa3g77.jpg'),(6,'sahil','sahil@gmail.com','$2a$10$cY3eixebUXc7vgOacWd5Se7fVgLyWj9ruT2Zjod.Lw5n7EIc1sW/y','User','https://res.cloudinary.com/dskt3xxtq/image/upload/v1680669621/uploads/ltkwuzpp9ubyicxv7wrj.jpg'),(10,'sss','ssss@gmail.com','$2a$10$cWET4MfeFl49CG4abp8H6O13iHCVJwGT7YHnoZzCRlWAF67wZb.za','User',''),(11,'aziz','aziz@gmail.com','$2a$10$Z0Slek4X/emKoXpNsgRzZun24nihEO9fIJp62hGR0H0ZGcLryd4Qq','User','');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'khadijac_charity_foundation'
--

--
-- Dumping routines for database 'khadijac_charity_foundation'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-02 21:23:12
